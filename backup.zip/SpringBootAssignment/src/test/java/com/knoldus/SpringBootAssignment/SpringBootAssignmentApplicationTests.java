package com.knoldus.SpringBootAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
