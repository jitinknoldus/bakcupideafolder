package Junit_Practice;

public class MathUtils {
    public static void int add(int a, int b){
        return a+b;
    }
}
