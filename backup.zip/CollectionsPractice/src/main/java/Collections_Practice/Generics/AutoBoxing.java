package Collections_Practice.Generics;

public class AutoBoxing {
    public static void main(String[] args) {
        int x = 10;
        Integer i = x;

        System.out.println(x);
    }
}
