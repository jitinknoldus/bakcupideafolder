package com.knoldus.SpringJpaJavaBrains;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaJavaBrainsApplicationTests {

	@Test
	void contextLoads() {
	}

}
