//package com.knoldus1;
//
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class AppConfig {
//    @Bean(name="demoService")
//    public Student getStudent(){
//        return new Student();
//    }
//}