package Controller;

public class HelloWorld {

    @Get
    public String display(){
        return "Hello World";
    }
}
