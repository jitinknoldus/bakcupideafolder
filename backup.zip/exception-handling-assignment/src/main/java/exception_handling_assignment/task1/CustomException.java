package exception_handling_assignment.task1;

public class CustomException extends Exception{
    CustomException(String message){
        super(message);
    }
}
