package exception_handling_assignment.task2;

public class CustomGameException extends Exception {

    CustomGameException(String message){
        super(message);
    }

}
