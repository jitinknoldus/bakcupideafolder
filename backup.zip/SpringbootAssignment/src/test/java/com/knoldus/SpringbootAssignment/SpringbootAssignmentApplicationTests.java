package com.knoldus.SpringbootAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
