package Things_To_Know_In_Java.task12;

public class Main {
    public static void main(String[] args) {
            GetterSetter getterSetterObject = new GetterSetter();
            getterSetterObject.setMyNumber(42);
            System.out.println("getting my number "+getterSetterObject.getMyNumber());

    }
}
