package Things_To_Know_In_Java.task12;

public class GetterSetter {

    private int myNumber;

    public int getMyNumber() {
        return myNumber;
    }

    public void setMyNumber(int num) {
        myNumber = num;
    }
}
