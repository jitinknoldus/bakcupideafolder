package Things_To_Know_In_Java.task15.package1;

public class Class1 {
        int myDefaultVariable = 104;
}
