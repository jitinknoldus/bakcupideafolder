package com.knoldus.javabasics.task9;

//java basics assignment task 9

public class ConvertingToUpperCase {

        public static void main (String[] args) {
            String message = "Hello";
            message = message.toUpperCase();
            System.out.println(message);
        }
}
