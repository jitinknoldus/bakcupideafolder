package com.knoldus.javabasics.task6;

//java basics assignment task 6
public class TypeCastingDouble {

    public static void main(String[] args) {

        double distance = 5;
        int typecasted_distance = (int) distance;
        System.out.println(typecasted_distance);

    }
}
