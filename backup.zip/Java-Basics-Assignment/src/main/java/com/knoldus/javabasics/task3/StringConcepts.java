package com.knoldus.javabasics.task3;

//java assignment task 3

public class StringConcepts {
    public static void main(String args[]){
        String name = "John";
        String message = "is an intern ";
        System.out.println(name + " " + message);
    }
}
