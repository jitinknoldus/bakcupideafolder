package com.knoldus.javabasics.task5;

//java basics assignment task 5
public class DecreasingSequence {
    public static void main(String[] args) {
        int x = 10;

        while(x>0){
            System.out.print(x + " ");
            x -= 1;
        }
    }
}
