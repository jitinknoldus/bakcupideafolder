package com.knoldus.javabasics.task2;

// java assignment task 2

public class DoubleConcepts {
    public static void main(String args[]){
        double num1 = 3.14;
        double num2 = 6.28;
        System.out.println(num1 + num2);
    }
}
