package com.knoldus.javabasics.task4;

//java basics assignment task  4
public class BooleanConcepts {
    public static void main(String[] args) {
        Boolean isRaining = true;

        if(isRaining){
            System.out.println("Take an Umbrella");
        }else{
            System.out.println("Enjoy the sunshine");
        }
    }
}
