package com.knoldus.javabasics.task8;

//java basics assignment task 7

public class CircleOperations {

    public static void main(String[] args) {
        double radius = 3;
        double pi = 3.14;

        double circumference = 2*pi*radius;
        double area = pi*radius*radius;

        System.out.println("Area is :"+area);
        System.out.println("Circumference is: "+ circumference);

    }

}
