package com.knoldus.javabasics.task1;

//java assignment task-1
public class IntegerConcepts {

    public static void main(String args[]){

        int age = 25;

    }
}
